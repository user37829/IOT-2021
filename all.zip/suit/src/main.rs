#![no_std]
#![no_main]
#![feature(default_alloc_error_handler)]
extern crate alloc;

mod state;
mod beacons;
mod minifmt;
mod data;

use alloc::vec;
use alloc_cortex_m::CortexMHeap;
use cortex_m_rt::entry;
use embedded_hal::digital::v2::OutputPin;
use panic_halt as _;
use protocol_types::MqttPacket;
use stm32f1xx_hal::{adc, delay::Delay, pac, prelude::*, serial::{Config, Serial, StopBits}};
use rand::prelude::*;
use rand_chacha::ChaCha8Rng;

//static TX_QUEUE: Mutex<Vec<MqttPacket>> = Mutex::new(vec![]);

#[entry]
fn main() -> ! {
    let start = cortex_m_rt::heap_start() as usize;
    let size = 2448; // in bytes
    unsafe { ALLOCATOR.init(start, size) }
    let p = cortex_m::Peripherals::take().unwrap();
    let dp = pac::Peripherals::take().unwrap();
    let mut flash = dp.FLASH.constrain();
    let mut rcc = dp.RCC.constrain();
    let clocks = rcc
        .cfgr
        .use_hse(8.mhz())
        .sysclk(48.mhz())
        .pclk1(24.mhz())
        .freeze(&mut flash.acr);
    let mut delay = Delay::new(p.SYST, clocks);
    let mut adc1 = adc::Adc::adc1(dp.ADC1, &mut rcc.apb2, clocks);

    let mut gpioc = dp.GPIOC.split(&mut rcc.apb2);
    let mut gpioa = dp.GPIOA.split(&mut rcc.apb2);
    let mut led = gpioc.pc13.into_push_pull_output(&mut gpioc.crh);
    let mut dht11 = gpioa.pa10.into_open_drain_output(&mut gpioa.crh);
    let mut oxygen_sensor = gpioa.pa0.into_analog(&mut gpioa.crl);
    let mut enable_motion = gpioa.pa11.into_pull_up_input(&mut gpioa.crh);
    dht11.set_high();
    led.set_high();
    let beacons_generator = beacons::BeaconsGenerator::default();
    let rng = ChaCha8Rng::seed_from_u64(22u64);
    let mut devices = state::Devices {
        led: led.downgrade(),
        dht11: dht11.downgrade(),
        enable_motion: enable_motion.downgrade(),
        adc1,
        oxygen_sensor,
        delay,
        beacons_generator,
        rng
    };

    let mut afio = dp.AFIO.constrain(&mut rcc.apb2);

    let mut gpiob = dp.GPIOB.split(&mut rcc.apb2);
    let tx = gpiob.pb10.into_alternate_push_pull(&mut gpiob.crh);
    let rx = gpiob.pb11;

    let mut serial = Serial::usart3(
        dp.USART3,
        (tx, rx),
        &mut afio.mapr,
        Config::default()
            .parity_none()
            .stopbits(StopBits::STOP1)
            .baudrate(9600.bps()),
        clocks,
        &mut rcc.apb1,
    );
    let (mut tx, mut rx) = serial.split();
    let mut state = state::State::new();
    loop {
        let size = nb::block!(rx.read()).unwrap();
        let mut packet_buffer = vec![0x00u8; size as usize];
        for b in &mut packet_buffer {
            *b = nb::block!(rx.read()).unwrap();
        }
        if let Ok(packet) = serde_cbor::from_slice::<MqttPacket>(&packet_buffer) {
            let new_pckt = state.packet_received(packet, &mut devices);
            state.apply(&mut devices);
            if let Some(new_pckt) = new_pckt {
                let send_buf = new_pckt.into_packet_bytes();
                for b in send_buf {
                    nb::block!(tx.write(b));
                }
            }
        }
    }
}

#[global_allocator]
static ALLOCATOR: CortexMHeap = CortexMHeap::empty();
