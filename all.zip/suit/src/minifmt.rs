use alloc::{vec, string::String};

pub fn format_u8(mut val: u8) -> String {
    let mut digits = vec![];
    while val > 0 {
        digits.push(b'0' + (val % 10));
        val /= 10;
    }
    digits.reverse();
    unsafe { String::from_utf8_unchecked(digits) }
}