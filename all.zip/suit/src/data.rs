use serde::Serialize;
use alloc::string::String;
#[derive(Serialize)]
pub struct Coords {
    pub x: i32,
    pub y: i32,
    pub z: i32,
}

#[derive(Serialize)]
pub struct Env {
    pub humidity: u8,
    pub oxygen: u8,
}

#[derive(Serialize)]
pub struct Data {
    pub charge: u8,
    pub coords: Coords,
    pub env: Env,
    pub beacons: String,
}