use alloc::{string::String, vec};
use embedded_hal::digital::v2::{OutputPin, InputPin};
use embedded_hal::adc::OneShot;
use crate::minifmt::*;
use protocol_types::{MqttMessage, MqttPacket};
use stm32f1xx_hal::{adc::Adc, delay::Delay, gpio::{Analog, Input, OpenDrain, Output, PullUp, PushPull, Pxx, gpioa::PA0}, pac::ADC1};
use dht_sensor::*;
use rand_chacha::ChaCha8Rng;
use rand::prelude::*;
use serde::Serialize;
use crate::beacons::BeaconsGenerator;
use crate::data::*;

const ID: &'static str = "mqtt-iprofi_730109725-9d3gxv";

pub struct Devices {
    pub dht11: Pxx<Output<OpenDrain>>,
    pub led: Pxx<Output<PushPull>>,
    pub enable_motion: Pxx<Input<PullUp>>,
    pub oxygen_sensor: PA0<Analog>,
    pub adc1: Adc<ADC1>,
    pub delay: Delay,
    pub beacons_generator: BeaconsGenerator,
    pub rng: ChaCha8Rng,
}
pub struct State {
    suit_active: bool,
    charge: f32
}

impl State {
    pub fn new() -> Self {
        Self { suit_active: false, charge: 100.0 }
    }

    pub fn packet_received(&mut self, msg: MqttPacket, devices: &mut Devices) -> Option<MqttPacket> {
        let subs = vec![]; // опционально на какие топики подписано устройство
        match msg {
            MqttPacket::Ping(id) if id == Some(String::from(ID)) || id.is_none() => {
                Some(MqttPacket::Pong((String::from(ID), subs)))
            }
            MqttPacket::PollData(id) if id == String::from(ID) => {
                let reading = dht11::Reading::read(&mut devices.delay, &mut devices.dht11);
                let humidity = reading.map(|x| x.relative_humidity).unwrap();
                let oxygen_val: u16 = devices.adc1.read(&mut devices.oxygen_sensor).unwrap();
                let oxygen = ((oxygen_val as f32 * 100.0) / 4096.0) as u8;
                let x = devices.rng.gen_range(9..90);
                let y = devices.rng.gen_range(5..25);
                let z = -27;
                let coords = Coords {
                    x, y, z
                };
                self.charge -= 0.3;
                if self.charge < 0.0 {
                    self.charge = 0.0;
                }
                let beacons = devices.beacons_generator.get_next_base64(devices.enable_motion.is_high().unwrap());
                let data = Data {
                    charge: self.charge as u8,
                    coords,
                    env: Env {
                        humidity,
                        oxygen,
                    },
                    beacons
                };
                Some(MqttPacket::Message((
                    String::from(ID),
                    vec![MqttMessage { topic: String::from("data"), payload: serde_json::to_string(&data).unwrap() }],
                )))
            },
            MqttPacket::Command((id, MqttMessage { topic, payload })) if id == String::from(ID) => {
                match &topic[..] {
                    "suit_activate" => {
                        self.suit_active = payload == "1";
                        None
                    }
                    _ => None,
                }
            },
            _ => None
        }
    }

    pub fn apply(&self, devices: &mut Devices) {
        if self.suit_active {
            devices.led.set_low();
        } else {
            devices.led.set_high();
        }
    }
}
