use alloc::string::String;
use alloc::{vec, vec::Vec};

#[repr(packed)]
pub struct Beacon {
    mac: u16,
    rssi: i8,
}

#[repr(packed)]
pub struct Beacons {
    lat: f32,
    lon: f32,
    alt: f32,
    ev_time: u32,
    visible_count: u8,
    beacons: [Beacon; 8]
}

pub struct BeaconsGenerator {
    n_path: usize,
    n_step: u8,
    n_skip: u8,
    total_skip: u8,
    steps: u8,
    back: bool,
    path: Vec<[(f32, f32); 2]>,
}

impl Default for BeaconsGenerator {
    fn default() -> Self {
        Self {
            n_path: 0,
            n_step: 0,
            n_skip: 0,
            total_skip: 13,
            steps: 8,
            back: false,
            path: vec![
                [(67.5, 64.04), (67.5348, 63.7904)],
                [(67.5348, 63.7904), (67.594864, 64.081003)],
                [(67.594864, 64.081003), (67.62, 64.141)],
                [(67.62, 64.141), (67.62, 64.141)],
                [(67.62, 64.141), (67.5, 64.15)],
                [(67.5, 64.15), (67.5, 64.04)],
            ],
        }
    }
}

impl BeaconsGenerator {
    pub fn get_next_base64(&mut self, update: bool) -> String {
        let [(lat_from, lon_from),  (lat_to, lon_to)] = self.path[self.n_path];
        let lat = lat_from + (lat_to - lat_from)*(self.n_step as f32) / (self.steps as f32);
        let lon = lon_from + (lon_to - lon_from)*(self.n_step as f32) / (self.steps as f32);
        if self.n_step == 0 && self.n_skip <= self.total_skip && self.n_path == 1  {
            self.n_skip += 1;
        } else if update  {
            self.n_skip = 0;
            self.n_step += 1;
            if self.n_step == self.steps {
                self.n_step = 0;
                self.n_path = (self.n_path + 1) % self.path.len();
            }
        }
        let beacons = Beacons {
            lat,
            lon,
            alt: 1.05,
            ev_time: 1618892350,
            visible_count: 8,
            beacons: [
                Beacon { mac: 0x9812_u16, rssi: 0 },
                Beacon { mac: 0x0a35_u16, rssi: -127 },
                Beacon { mac: 0x2939_u16, rssi: -127 },
                Beacon { mac: 0xd396_u16, rssi: -65 },
                Beacon { mac: 0xf741_u16, rssi: -65 },
                Beacon { mac: 0x01dd_u16, rssi: -127 },
                Beacon { mac: 0x08cd_u16, rssi: 0 },
                Beacon { mac: 0x0e60_u16, rssi: -127 },
            ]
        };
        let buf: [u8; core::mem::size_of::<Beacons>()] = unsafe { core::mem::transmute(beacons) };
        base64::encode(&buf)
    }
}