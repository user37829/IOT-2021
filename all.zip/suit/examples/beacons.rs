#![allow(dead_code)]
use paho_mqtt::{Client, ConnectOptionsBuilder, Message, QOS_1};
use std::time::{Duration};
use rand_chacha::ChaCha8Rng;
use rand::prelude::*;
use suit::*;

fn main() {
    let cli = Client::new((
        "tcp://sandbox.rightech.io:1883",
        "mqtt-iprofi_730109725-9d3gxv",
    ))
    .unwrap();
    let conn_opts = ConnectOptionsBuilder::new()
        .keep_alive_interval(Duration::from_secs(20))
        .clean_session(true)
        .finalize();
    cli.connect(conn_opts).unwrap();
    let mut beacons_generator = BeaconsGenerator::default();
    let mut rng = ChaCha8Rng::seed_from_u64(22u64);
    let mut charge = 100.0;
    loop {
        let coords = Coords {
            x: rng.gen_range(1..20),
            y: rng.gen_range(1..20),
            z: -27,
        };
        let env = Env {
            humidity: rng.gen_range(0..100),
            oxygen: 22,
        };
        let beacons = "CtSLQu35ckLNO4Y/vpUOYAQSmIE1CoE5KYGW04E=".to_string(); //beacons_generator.get_next_base64(true);
        let data = Data {
            charge: charge as u8,
            coords,
            env,
            beacons
        };
        charge -= 0.3;
        cli.publish(Message::new("data", serde_json::to_string(&data).unwrap(),  QOS_1)).unwrap();
        std::thread::sleep(Duration::from_secs(1));
    }
}
