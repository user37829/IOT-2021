#![no_std]
extern crate alloc;
use serde::{Serialize, Deserialize};
use alloc::{string::String, vec, vec::Vec};

#[derive(Serialize, Deserialize)]
pub struct MqttMessage {
    pub topic: String,
    pub payload: String,
}

#[derive(Serialize, Deserialize)]
pub enum MqttPacket {
    Ping(Option<String>),
    Pong((String, Vec<String>)),
    PollData(String),
    Message((String, Vec<MqttMessage>)),
    Command((String, MqttMessage)),
}

impl MqttPacket {
    pub fn into_packet_bytes(&self) -> Vec<u8> {
        let msg_buf = serde_cbor::to_vec(&self).unwrap();
        let mut buf = vec![];
        buf.extend_from_slice(&(msg_buf.len() as u8).to_be_bytes());
        buf.extend_from_slice(&msg_buf);
        buf
    }

    pub fn from_packet_bytes(buf: &[u8]) -> serde_cbor::Result<Self> {
        let len = u8::from_be_bytes([buf[0]]) as usize;
        serde_cbor::from_slice(&buf[1..len+1])
    }
}