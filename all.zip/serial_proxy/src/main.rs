use tokio_serial::Serial;
use tokio::time::Duration;
use simple_logger::SimpleLogger;
use structopt::StructOpt;

mod packet_io;
mod connection_pool;

/// Serial/MQTT router
#[derive(StructOpt, Debug, Clone)]
pub struct Opt {
    /// Server address
    #[structopt(short, long, default_value="tcp://sandbox.rightech.io:1883")]
    server: String,
    /// Serial device path
    #[structopt(short, long, default_value="/dev/ttyUSB0")]
    dev: String,
    /// Poll timeout (seconds)
    #[structopt(long, default_value="3")]
    poll_timeout: u64,
    /// Serial packet read timeout (seconds)
    #[structopt(long, default_value="15")]
    read_timeout: u64,
    /// Min. refresh interval (seconds)
    #[structopt(long, default_value="1")]
    refresh: u64,
}

#[tokio::main]
async fn main() -> std::io::Result<()> {
    SimpleLogger::new().with_level(log::LevelFilter::Info).init().unwrap();
    let opt = Opt::from_args();
    let serial = Serial::from_path(&opt.dev, &Default::default()).unwrap();
    let mut pool = connection_pool::MqttConnectionPool::new("tcp://sandbox.rightech.io:1883", serial, opt.clone());
    pool.collect_ids().await.unwrap();
    loop {
        let polling_future = pool.poll_all();
        let min_timeout_future = tokio::time::delay_for(Duration::from_secs(opt.refresh));
        let (polling_res, _) = tokio::join!(polling_future, min_timeout_future);
        if let Err(e) = polling_res {
            log::warn!("{}", e);
        }
    }
}
