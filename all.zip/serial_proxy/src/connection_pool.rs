use std::{collections::HashMap, time::Duration};
use anyhow::Result;
use futures_channel::mpsc::Receiver;
use futures::stream::{self, StreamExt};
use paho_mqtt::{AsyncClient, Message, QOS_1, ConnectOptionsBuilder};
use tokio::io::{AsyncRead, AsyncWrite};
use tokio::sync::Mutex;
use protocol_types::{MqttMessage, MqttPacket};
use crate::packet_io::{receive_packet, send_packet, collect_ids};
use crate::Opt;

pub struct MqttConnectionPool<S: AsyncRead + AsyncWrite + Unpin> {
    broker: String,
    pool_tx: HashMap<String, AsyncClient>,
    pool_rx: Mutex<HashMap<String, Receiver<Option<Message>>>>,
    stream: Mutex<S>,
    opt: Opt,
}

impl<S: AsyncRead + AsyncWrite + Unpin> MqttConnectionPool<S> {
    pub fn new(broker: &str, stream: S, opt: Opt) -> Self {
        Self { pool_tx: HashMap::new(), pool_rx: Mutex::new(HashMap::new()), broker: broker.to_owned(), stream: Mutex::new(stream), opt }
    }

    pub async fn collect_ids(&mut self) -> Result<()> {
        let new = collect_ids(&mut *self.stream.lock().await, self.opt.poll_timeout).await?;
        for (id, subs) in new {
            if !self.pool_tx.contains_key(&id) {
                let mut client = AsyncClient::new((&self.broker[..], &id[..]))?;
                let rx = client.get_stream(32);
                let conn_opts = ConnectOptionsBuilder::new()
                    .keep_alive_interval(Duration::from_secs(20))
                    .clean_session(true)
                    .finalize();
                client.connect(conn_opts).await?;
                for topic in subs {
                    client.subscribe(&topic, QOS_1).await?;
                }
                self.pool_tx.insert(id.clone(), client);
                self.pool_rx.lock().await.insert(id, rx);
            }
        }
        Ok(())
    }

    pub async fn poll_data(&self) -> Result<()> {
        let active_keys: Vec<_> = self.pool_tx.keys().map(|x| x.to_owned()).collect();
        for id in active_keys {
            let pkt = MqttPacket::PollData(id.clone());
            send_packet(&mut *self.stream.lock().await, pkt).await?;
            self.route_to_broker().await?;
        }
        Ok(())
    }

    pub async fn route_to_broker(&self) -> Result<()> {
        let p = tokio::time::timeout(Duration::from_secs(self.opt.read_timeout), receive_packet(&mut *self.stream.lock().await)).await??;
        if let MqttPacket::Message((id, msgs)) = p {
            if let Some(client) = self.pool_tx.get(&id) {
                for msg in msgs {
                    let MqttMessage { topic, payload } = msg;
                    client.publish(Message::new(topic, payload, QOS_1)).await?;
                }
            }
        }
        Ok(())
    }

    pub async fn poll_all(&self) -> Result<()> {
        let mut rx = self.pool_rx.lock().await;
        let commands_future = stream::iter(rx.iter_mut()).then(|(id, recv)| async move {
            (id.to_owned(), recv.try_next().map(|x| x.flatten()).ok().flatten())
        })
        .filter_map(|(id, msg)| async {
            Some((id, msg?))
        })
        .map(move |(id, msg)| {
            MqttPacket::Command((id, MqttMessage {
                topic: msg.topic().to_owned(),
                payload: msg.payload_str().to_string(),
            }))
        }).collect::<Vec<_>>();
        let (commands, data_res) = tokio::join!(commands_future, self.poll_data());
        data_res?;
        for command in commands {
            send_packet(&mut *self.stream.lock().await, command).await?;
        }
        Ok(())
    }
}