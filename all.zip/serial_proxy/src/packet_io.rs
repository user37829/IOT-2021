use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};
use tokio::time::timeout;
use anyhow::Result;
use protocol_types::MqttPacket;
use std::{collections::HashMap, time::Duration};

pub async fn send_packet<W: AsyncWrite + Unpin>(stream: &mut W, packet: MqttPacket) -> Result<()> {
    stream.write_all(&packet.into_packet_bytes()).await?;
    Ok(())
}

pub async fn receive_packet<R: AsyncRead + Unpin>(stream: &mut R) -> Result<MqttPacket> {
    let size = stream.read_u8().await?;
    let mut buf = vec![0x00u8; size as usize];
    stream.read_exact(&mut buf).await?;
    let pkt = serde_cbor::from_slice(&buf)?;
    Ok(pkt)
}

pub async fn collect_ids<S>(stream: &mut S, tm: u64) -> Result<HashMap<String, Vec<String>>> 
where
    S: AsyncRead + AsyncWrite + Unpin
{
    let mut all_ids = HashMap::new();
    send_packet(stream, MqttPacket::Ping(None)).await?;
    while let Ok(pkt) = timeout(Duration::from_secs(tm), receive_packet(stream)).await {
        if let Ok(pkt) = pkt {
            match pkt {
                MqttPacket::Pong((id, subs)) => { all_ids.insert(id, subs); },
                _ => (),
            }
        }
    }
    log::info!("Connected {} device(s)", all_ids.len());
    Ok(all_ids)
}